import { Reclamation } from './reclamation';

describe('Reclamation', () => {
  it('should create an instance', () => {
    expect(new Reclamation()).toBeTruthy();
  });
});

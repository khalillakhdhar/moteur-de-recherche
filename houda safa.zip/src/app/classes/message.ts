export class Message {
    id:string;
    text:string;
    date:string;
   pseudo:string;
}

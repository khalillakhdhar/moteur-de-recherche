export class Equipe {
    id:string;
    titre:string;
    descirption:string;
    domaine:string;


}

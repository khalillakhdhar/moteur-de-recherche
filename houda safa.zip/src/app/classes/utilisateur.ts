export class Utilisateur {
    id:string;
    nom:string;
    age:number;
    email:string;
    mdp:string;
    telephone:string;
    adresse:string;
    grade:string;
    equipe:string;
}

export class Document {
    id:string;
    titre:string;
    description:string;
    date:string;
    url:string;
    
    
}

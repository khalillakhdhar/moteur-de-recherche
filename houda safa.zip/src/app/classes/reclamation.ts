export class Reclamation {
}
